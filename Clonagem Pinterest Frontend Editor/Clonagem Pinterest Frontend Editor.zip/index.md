Anotacoes

